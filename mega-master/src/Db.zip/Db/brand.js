const brand = [
    {
        id: "1",
        name: "sony",
        src: require("../Image/Brands/sony.png"),
        link: "http://www.testproject.pro/brands/sony"
    },
    {
        id: "2",
        name: "acer",
        src: require("../Image/Brands/acer.png"),
        link: "http://www.testproject.pro/brands/acer"
    },
    {
        id: "3",
        name: "asus",
        src: require("../Image/Brands/asus.png"),
        link: "http://www.testproject.pro/brands/asus"
    },
    {
        id: "4",
        name: "huawei",
        src: require("../Image/Brands/hu.png"),
        link: "http://www.testproject.pro/brands/huawei"
    },
    {
        id: "5",
        name: "lenovo",
        src: require("../Image/Brands/lenovo.png"),
        link: "http://www.testproject.pro/brands/lenovo"
    },
    {
        id: "6",
        name: "meizu",
        src: require("../Image/Brands/me.png"),
        link: "http://www.testproject.pro/brands/meizu"
    },
    {
        id: "7",
        name: "xiaomi",
        src: require("../Image/Brands/mi.png"),
        link: "http://www.testproject.pro/brands/xiaomi"
    },
    {
        id: "8",
        name: "packard-bell",
        src: require("../Image/Brands/packard-bell.png"),
        link: "http://www.testproject.pro/remont-noutbukov/remont-noutbukov-packard-bell"
    },
    {
        id: "9",
        name: "samsung",
        src: require("../Image/Brands/sam.png"),
        link: "http://www.testproject.pro/brands/samsung"
    }
]
export default brand;