const fly = [
    {
        id: "1",
        title: "FLY",
        name: "U11",
        src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-htc/remont-htc-u11.html",
        img: require("U11.jpg")
    },
]
export default fly;
