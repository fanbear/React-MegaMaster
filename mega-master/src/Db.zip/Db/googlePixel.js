const googlePixel = [
    {
        id: "1",
        title: "Pixel",
        name: "2",
        src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-google-pixel/remont-google-pixel-2.html",
        img: require("../Image/GooglePixel/pixel-2.jpg")
    },
    {
        id: "2",
        title: "Pixel",
        name: "2xl",
        src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-google-pixel/remont-google-pixel-2xl.html",
        img: require("../Image/GooglePixel/pixel-2xl.jpg")
    },
    {
        id: "3",
        title: "Pixel",
        name: "3",
        src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-google-pixel/remont-google-pixel-3.html",
        img: require("../Image/GooglePixel/pixel-3.jpg")
    },
    {
        id: "4",
        title: "Pixel",
        name: "3xl",
        src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-google-pixel/remont-google-pixel-3-xl.html",
        img: require("../Image/GooglePixel/pixel-3xl.jpg")
    },
]
export default googlePixel;