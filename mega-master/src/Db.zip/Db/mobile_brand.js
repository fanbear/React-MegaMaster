const mobile_brand_db = [
    {
        id: 1,
      //   title: "ремонт телефонов",
        name: "Samsung",
        img: require("../Image/MobileBrand/samsung.png"),
        src: "/samsung"    
    },
    {
        id: 2,
      //   title: "ремонт телефонов",
        name: "Nokia",
        img: require("../Image/MobileBrand/nokia.png"),
        src: "/nokia"    
     },
     {
        id: 3,
      //   title: "ремонт телефонов",
        name: "HTC",
        img: require("../Image/MobileBrand/Htc.png"),
        src: "/htc" 
     },
      
     {
        id: 4,
      //   title: "ремонт телефонов",
        name: "LG",
        img: require("../Image/MobileBrand/LG.png"),
        src: "/lg" 
     },
      
     {
        id: 5,
      //   title: "ремонт телефонов",
        name: "Apple",
        img: require("../Image/MobileBrand/apple.png"),
        src: "/apple" 
     },
      
    //  {
    //     id: 6,
    //   //   title: "ремонт телефонов",
    //     name: "FLY",
    //     img: require("../Image/MobileBrand/fly.png"),
    //     src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-fly.html" 
    //  },
      
     {
        id: 7,
      //   title: "ремонт телефонов",
        name: "Lenovo",
        img: require("../Image/MobileBrand/lenovo.png"),
        src: "/lenovo" 
     },
      
     {
        id: 8,
      //   title: "ремонт телефонов",
        name: "Sony",
        img: require("../Image/MobileBrand/sony.png"),
        src: "/sony" 
     },
      
     {
        id: 9,
      //   title: "ремонт телефонов",
        name: "Xiaomi",
        img: require("../Image/MobileBrand/xiaomi.png"),
        src: "/xiaomi" 
     },
      
     {
        id: 10,
      //   title: "ремонт телефонов",
        name: "Meizu",
        img: require("../Image/MobileBrand/meizu.png"),
        src: "/meizu" 
     },
      
     {
        id: 11,
      //   title: "ремонт телефонов",
        name: "Asus",
        img: require("../Image/MobileBrand/asus.png"),
        src: "/asus" 
     },
      
     {
        id: 12,
      //   title: "ремонт телефонов",
        name: "Huawei",
        img: require("../Image/MobileBrand/huawei.png"),
        src: "/huawei" 
     },
      
    //  {
    //     id: 13,
    //   //   title: "ремонт телефонов",
    //     name: "Philips",
    //     img: require("../Image/MobileBrand/philips.png"),
    //     src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-philips.html" 
    //  },
      
    //  {
    //     id: 14,
    //   //   title: "ремонт телефонов",
    //     name: "Jiayu",
    //     img: require("../Image/MobileBrand/jiayu.png"),
    //     src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-mobilnyix-telefonov-remont-telefonov-jiayu.html" 
    //  },
      
     {
        id: 15,
      //   title: "ремонт телефонов",
        name: "Motorola",
        img: require("../Image/MobileBrand/motorola.png"),
        src: "/motorola" 
     },
      
     {
        id: 16,
      //   title: "ремонт телефонов",
        name: "Google Pixel",
        img: require("../Image/MobileBrand/google pixel.png"),
        src: "/google-pixel" 
     },
      
     {
        id: 17,
      //   title: "ремонт телефонов",
        name: "Honor",
        img: require("../Image/MobileBrand/honor.png"),
        src: "/honor" 
     },
     {
        id: 18,
      //   title: "ремонт телефонов",
        name: "OnePlus",
        img: require("../Image/MobileBrand/oneplus.png"),
        src: "/one-plus"
     }
]

export default mobile_brand_db;
