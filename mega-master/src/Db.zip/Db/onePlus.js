const onePlus = [
    {
        id: "1",
        title: "ONEPLUS",
        name: "ONE",
        src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-oneplus/remont-oneplus-one.html",
        img: require("../Image/OnePlus/one.jpg")
    },
    {
        id: "2",
        title: "ONEPLUS",
        name: "2",
        src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-oneplus/remont-oneplus-2.html",
        img: require("../Image/OnePlus/OnePlus-2.jpg")
    },
    {
        id: "3",
        title: "ONEPLUS",
        name: "3(3t)",
        src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-oneplus/remont-oneplus-3-3t.html",
        img: require("../Image/OnePlus/OnePlus-3.jpg")
    },
    {
        id: "4",
        title: "ONEPLUS",
        name: "5",
        src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-oneplus/remont-oneplus-5.html",
        img: require("../Image/OnePlus/OnePlus-5.jpg")
    },
    {
        id: "5",
        title: "ONEPLUS",
        name: "5t",
        src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-oneplus/remont-oneplus-5t.html",
        img: require("../Image/OnePlus/OnePlus-5t.jpg")
    },
    {
        id: "6",
        title: "ONEPLUS",
        name: "6",
        src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-oneplus/remont-oneplus-6.html",
        img: require("../Image/OnePlus/OnePlus-6.jpg")
    },
    {
        id: "7",
        title: "ONEPLUS",
        name: "6t",
        src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-oneplus/remont-oneplus-6t.html",
        img: require("../Image/OnePlus/OnePlus-6t.jpg")
    },
    {
        id: "8",
        title: "ONEPLUS",
        name: "7",
        src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-oneplus/remont-oneplus-7.html",
        img: require("../Image/OnePlus/OnePlus-7.jpg")
    },
    {
        id: "9",
        title: "ONEPLUS",
        name: "7 Pro",
        src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-oneplus/remont-oneplus-7-pro.html",
        img: require("../Image/OnePlus/OnePlus-7pro.jpg")
    },
    {
        id: "10",
        title: "ONEPLUS",
        name: "X",
        src: "http://www.testproject.pro/remont-mobilnyix-telefonov/remont-telefonov-oneplus/remont-oneplus-x.html",
        img: require("../Image/OnePlus/OnePlus-x.jpg")
    }
]
export default onePlus;